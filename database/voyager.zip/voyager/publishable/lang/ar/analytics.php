<?php

return [
    'by_pageview'            => 'حسب المشاهدات',
    'by_sessions'            => 'حسب الجلسات',
    'by_users'               => 'حسب المستخدمين',
    'no_client_id'           => 'لعرض التحليلات، ستحتاج إلى الحصول على معرف عميل google analytics وإضافته إلى إعدادات المفتاح <code> google_analytics_client_id </code>. احصل على المفتاح من لوحة تحكم مطوري جوجل:',
    'set_view'               => 'حدد طريقة العرض',
    'this_vs_last_week'      => 'هذا الأسبوع ضد الأسبوع الماضي',
    'this_vs_last_year'      => 'هذا العام ضد العام الماضي',
    'top_browsers'           => 'أفضل المتصفحات',
    'top_countries'          => 'أعلى البلدان',
    'various_visualizations' => 'تصورات مختلفة',
];

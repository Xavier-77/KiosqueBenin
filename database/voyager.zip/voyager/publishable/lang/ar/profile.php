<?php

return [
    'avatar'                 => 'الصورة الرمزية',
    'edit'                   => 'تعديل',
    'edit_user'              => 'تعديل المستخدم',
    'password'               => 'كلمه السر',
    'password_hint'          => 'اتركها فارغة إذا لم ترد التعديل عليها',
    'role'                   => 'الدور',
    'user_role'              => 'دور المستخدم',
    'role_default'           => 'الصلاحية',
    'roles_additional'       => 'الصلاحية الإضافية',
];

<?php

return [
    'field_password_keep'          => 'Оставьте пустым, если не хотите менять пароль',
    'field_select_dd_relationship' => 'Обязательно настройте соответствующие отношения (relationship) в методе :method класса :class.',
    'type_checkbox'                => 'Флажок',
    'type_codeeditor'              => 'Редактор кода',
    'type_file'                    => 'Файл',
    'type_image'                   => 'Изображение',
    'type_radiobutton'             => 'Радио-кнопка',
    'type_richtextbox'             => 'Визуальный редактор',
    'type_selectdropdown'          => 'Выпадающий список',
    'type_textarea'                => 'Многострочный текст',
    'type_textbox'                 => 'Однострочный текст',
];

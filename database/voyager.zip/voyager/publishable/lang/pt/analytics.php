<?php

return [
    'by_pageview'            => 'Por pageview',
    'by_sessions'            => 'Por sessions',
    'by_users'               => 'Por users',
    'no_client_id'           => 'Para aceder ao analytics precisa adicionar nas Configurações do Voyager o key <code>google_analytics_client_id </code> com o código google analytics client id. Obtenha o seu key através do Google developer console:',
    'set_view'               => 'Selecionar Vista',
    'this_vs_last_week'      => 'Esta Semana vs Semana Passada',
    'this_vs_last_year'      => 'Este Ano vs Ano Passado',
    'top_browsers'           => 'Top Browsers',
    'top_countries'          => 'Top Países',
    'various_visualizations' => 'Visualizações várias',
];

<?php

return [
    'symlink_created_text'  => 'Loimme sinulle juuri puuttuneen symlinkkauksen.',
    'symlink_created_title' => 'Puuttunut tiedostovaraston symlinkkaus luotu',
    'symlink_failed_text'   => 'Epäonnistuimme luodessa puuttunutta symlinkkiä sovelluksellesi. '.
                                'Näyttää siltä että hostausalustasi ei tue sitä.',
    'symlink_failed_title'   => 'Puuttuneen symlinkkauksen luonti epäonnistui',
    'symlink_missing_button' => 'Korjaa asia',
    'symlink_missing_text'   => 'Emme löytäneet tiedostovaraston symlinkkausta. '.
                                'Tämä voi aiheuttaa ongelmia mediatiedostojen näyttämisen kanssa selaimessa.',
    'symlink_missing_title' => 'Tiedostovaraston puuttuva symlinkkaus',
];

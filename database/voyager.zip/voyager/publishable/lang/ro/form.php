<?php

return [
    'field_password_keep'          => 'Lăsați gol, dacă nu doriți să schimbați parola',
    'field_select_dd_relationship' => 'Este necesar să setați realțiile (relationship) în metoda :method din clasa :class.',
    'type_checkbox'                => 'Checkbox',
    'type_codeeditor'              => 'Editor de cod',
    'type_file'                    => 'Fișier',
    'type_image'                   => 'Imagine',
    'type_radiobutton'             => 'Radio buton',
    'type_richtextbox'             => 'Edito vizual',
    'type_selectdropdown'          => 'Listă dropdown',
    'type_textarea'                => 'Câmp text (textarea)',
    'type_textbox'                 => 'Câmp text (simplu)',
];

<?php

return [
    'footer_copyright'  => 'دروستکراوە بە  <i class="voyager-heart"></i> لەلایەن',
    'footer_copyright2' => 'دروستکراوە بە هەنگوین و هەنگوینی زیاتر',
];

<?php

return [
    'field_password_keep'          => 'بە بەتاڵی جێیبێلە بۆ ئەوەی وەک خۆی بمێنێتەوە',
    'field_select_dd_relationship' => 'دڵنیایبە لەوەی کە پەیوەندییەکی باش دروستدەکەیت لەناو مێتۆدی :method کە تایبەتە بە کڵاسی :class .',
    'type_checkbox'                => 'بۆکسی چێک',
    'type_codeeditor'              => 'دەستکاریکری کۆد',
    'type_file'                    => 'فایل',
    'type_image'                   => 'وێنە',
    'type_radiobutton'             => 'دوگمەی ڕادیۆ',
    'type_richtextbox'             => 'بۆکسی نوسینی تێر',
    'type_selectdropdown'          => 'هەڵبژاردنی بەرەوخوار',
    'type_textarea'                => 'ناوچەی نوسین',
    'type_textbox'                 => 'بۆکسی نوسین',
];

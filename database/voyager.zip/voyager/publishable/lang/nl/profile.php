<?php

return [
    'avatar'        => 'Avatar',
    'edit'          => 'Mijn profiel aanpassen',
    'edit_user'     => 'Gebruiker aanpassen',
    'password'      => 'Wachtwoord',
    'password_hint' => 'Leeg laten om hetzelfde te houden',
    'role'          => 'Rol',
    'user_role'     => 'Gebruikersrol',
];

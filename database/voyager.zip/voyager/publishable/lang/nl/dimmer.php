<?php

return [
    'page'           => 'Pagina|Pagina\'s',
    'page_link_text' => 'Toon alle pagina\'s',
    'page_text'      => 'U heeft :count :string in uw database. Klik op de knop hier onder om alle pagina\'s te bekijken.',
    'post'           => 'Post|Posts',
    'post_link_text' => 'Bekijk alle posts',
    'post_text'      => 'U heeft :count :string in uw database. Klik op de knop hier onder om alle posts te bekijken.',
    'user'           => 'Gebruiker|Gebruikers',
    'user_link_text' => 'Bekijk alle gebruikers',
    'user_text'      => 'U heeft :count :string in uw database. Klik op de knop hier onder om alle gebruikers te bekijken.',
];

<?php

return [
    'footer_copyright'  => 'Направено с <i class="voyager-heart"></i> от',
    'footer_copyright2' => 'Направено с ром и още ром',
];

<?php

return [
    'loggingin'    => 'Влизане',
    'signin_below' => 'Влезте по-долу:',
    'welcome'      => 'Добре дошли във Voyager. Липсващата Админ система за Ларавел',
];

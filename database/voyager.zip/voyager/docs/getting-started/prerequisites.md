# Prerequisites

Before installing Voyager make sure you have installed one of the following versions of Laravel:
- Laravel 6
- Laravel 7

Additionally Voyager requires you to use PHP 7.3 or newer.